const User = require('../models/userModel');
exports.getAllUsers = (req, res) => {
    User.getAllUsers((users) => {
        res.render('index', {users});
    });
};

exports.getUserById = (req, res) => {
    const userId = req.params.id;
    User.getUserById('userId', (user) => {
        res.render('edit', { user });
    });
};

//exibir usuário antes de deletar
exports.getdeleteByUser = (req, res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) => {
        res.render('dell', { user });
    });
};

exports.addUser = (req, res) => {
    const newUser = {
        name: req.body.name,
        email: req.body.email,
        fone: req.body.fone,
        addreess: req.body.address
    };
    User.addUser(newUser, () => {
        res.redirect('/');
    });
};

exports.updateUser = (req, res) => {
    const userId = req.params.is;
    const updateUser = {
        name: req.body.name,
        email: req.body.email,
        fone: req.body.fone,
        addreess: req.body.address
    };

    User.updateUser(userId, updateUser, () => {
        res.redirect('/');
    });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.is;
    User.deleteUser(userId, () => {
        res.redirect('/');
    });
};

